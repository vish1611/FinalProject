- Downloaded the XML files from https://www.nsf.gov/awardsearch/download.jsp

- Create ER diagram according to the XML file.

- Convert the XML file to CSV. 

- Once that is done, connect to the local server. I used phpMyAdmin for the connection. 

- Created a "project" database. 

- Then start importing the CSV to SQL.

- There will be an error for the string value and to over come that, "ALTER DATABASE YOURDB CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;" and the error should be done.

- The tables will be created but there won't be any data in the tables. 

- To get the data in the table, run the code again and there will be data as well in the table in the database. 

- And that's it. 