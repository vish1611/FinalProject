# Importing the required libraries
import pandas as pd
import mysql.connector as msql
from mysql.connector import Error

path = 'D:\\final_project\\CSVfiles\\'

awardData = pd.read_csv(path + 'award.csv',index_col=False)
awardData.head()

award_instrumentData = pd.read_csv(path + 'award_instrument.csv',index_col=False)
award_instrumentData.head()

appropriationData = pd.read_csv(path + 'appropriation.csv',index_col=False)
appropriationData.head()

directorateData = pd.read_csv(path + 'directorate.csv',index_col=False)
directorateData.head()

divisionData = pd.read_csv(path + 'division.csv',index_col=False)
divisionData.head()

fundData = pd.read_csv(path + 'fund.csv',index_col=False)
fundData.head()

institutionData = pd.read_csv(path + 'institution.csv',index_col=False)
institutionData.head()

investigatorData = pd.read_csv(path + 'investigator.csv',index_col=False)
investigatorData.head()

organizationData = pd.read_csv(path + 'organization.csv',index_col=False)
organizationData.head()

performance_institutionData = pd.read_csv(path + 'performance_institution.csv',index_col=False)
performance_institutionData.head()

program_elementData = pd.read_csv(path + 'program_element.csv',index_col=False)
program_elementData.head()

program_officerData = pd.read_csv(path + 'program_officer.csv',index_col=False)
program_officerData.head()

program_referenceData = pd.read_csv(path + 'program_reference.csv',index_col=False)
program_referenceData.head()

#Establishing the connection
try:
    conn = msql.connect(host='localhost', database='project', user='root', password='')
    if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("select database();")
        record = cursor.fetchone()
        print("You're connected to database: ", record)

        cursor.execute('DROP TABLE IF EXISTS award;')
        cursor.execute("CREATE TABLE award( AwardTitle VARCHAR(1024),AGENCY VARCHAR(1024),AwardEffectiveDate VARCHAR(1024),AwardExpirationDate VARCHAR(1024),AwardTotalIntnAmount VARCHAR(1024),AwardAmount BIGINT, AbstractNarration TEXT , MinAmdLetterDate VARCHAR(1024), MaxAmdLetterDate VARCHAR(1024), ARRAAmountTRAN_TYPE VARCHAR(222) , CFDA_NUM VARCHAR(1024), NSF_PAR_USE_FLAG BIGINT, FUND_AGCY_CODE BIGINT, AWDG_AGCY_CODE BIGINT, AwardID BIGINT, FUND_OBLG VARCHAR(1024), PRIMARY KEY  (AwardID))")

        cursor.execute('DROP TABLE IF EXISTS award_instrument;')
        cursor.execute("CREATE TABLE award_instrument (Value VARCHAR(1024), AwardID BIGINT)")

        cursor.execute('DROP TABLE IF EXISTS appropriation;')
        cursor.execute("CREATE TABLE appropriation (Code VARCHAR(1024), Name VARCHAR(1024), APP_SYMB_ID BIGINT, AwardID BIGINT)")

        cursor.execute('DROP TABLE IF EXISTS directorate;')
        cursor.execute("CREATE TABLE directorate (Abbreviation VARCHAR(1024), LongName VARCHAR(1024), OrganizationCode BIGINT)")

        cursor.execute('DROP TABLE IF EXISTS division;')
        cursor.execute("CREATE TABLE division (Abbreviation VARCHAR(1024), LongName VARCHAR(1024), OrganizationCode BIGINT)")

        cursor.execute('DROP TABLE IF EXISTS fund;')
        cursor.execute("CREATE TABLE fund (Code VARCHAR(1024), Name VARCHAR(1024), FUND_SYMB_ID VARCHAR(1024), AwardID BIGINT)")

        cursor.execute('DROP TABLE IF EXISTS institution;')
        cursor.execute("CREATE TABLE institution ( Name VARCHAR(1024),CityName VARCHAR(1024),ZipCode VARCHAR(1024),PhoneNumber BIGINT,StreetAddress VARCHAR(1024),StreetAddress2 VARCHAR(1024), CountryName VARCHAR(1024),StateName VARCHAR(1024),StateCode VARCHAR(1024), CONGRESSDISTRICT BIGINT,CONGRESS_DISTRICT_ORG VARCHAR(1024),ORG_UEI_NUM VARCHAR(1024), ORG_LGL_BUS_NAME VARCHAR(1024),ORG_PRNT_UEI_NUM VARCHAR(1024),AwardID BIGINT)")

        cursor.execute('DROP TABLE IF EXISTS investigator;')
        cursor.execute("CREATE TABLE investigator ( FirstName VARCHAR(1024),LastName VARCHAR(1024),PI_MID_INIT VARCHAR(1024), PI_SUFX_NAME VARCHAR(1024),PI_FULL_NAME VARCHAR(1024),EmailAddress VARCHAR(1024),NSF_ID VARCHAR(1024), StartDate VARCHAR(1024),EndDate VARCHAR(1024), RoleCode VARCHAR(1024),AwardID BIGINT)")

        cursor.execute('DROP TABLE IF EXISTS organization;')
        cursor.execute("CREATE TABLE organization (Code BIGINT, AwardID BIGINT)")

        cursor.execute('DROP TABLE IF EXISTS performance_institution;')
        cursor.execute("CREATE TABLE performance_institution ( Name VARCHAR(1024),CityName VARCHAR(1024),StateCode VARCHAR(1024),ZipCode VARCHAR(1024),StreetAddress VARCHAR(1024),CountryCode VARCHAR(1024),CountryName VARCHAR(1024),StateName VARCHAR(1024),CountryFlag VARCHAR(1024),CONGRESSDISTRICT VARCHAR(1024),CONGRESS_DISTRICT_PERF VARCHAR(1024), AwardID BIGINT)")

        cursor.execute('DROP TABLE IF EXISTS program_element;')
        cursor.execute("CREATE TABLE program_element ( Code VARCHAR(1024),Text VARCHAR(1024), AwardID BIGINT)")

        cursor.execute('DROP TABLE IF EXISTS program_officer;')
        cursor.execute("CREATE TABLE program_officer ( SignBlockName VARCHAR(1024),PO_EMAI VARCHAR(1024),PO_PHON VARCHAR(1024), AwardID BIGINT)")

        cursor.execute('DROP TABLE IF EXISTS program_reference;')
        cursor.execute("CREATE TABLE program_reference ( Code VARCHAR(1024),Text VARCHAR(1024), AwardID BIGINT)")

        cursor.execute('DROP TABLE IF EXISTS award_institution;')
        cursor.execute("CREATE TABLE award_institution (AwardID BIGINT, Name VARCHAR(1024),CityName VARCHAR(1024), StateName VARCHAR(1024), ORG_UEI_NUM VARCHAR(1024), ORG_LGL_BUS_NAME VARCHAR(1024), FOREIGN KEY(AwardID) REFERENCES award(AwardID))")

        cursor.execute('DROP TABLE IF EXISTS award_investigator;')
        cursor.execute("CREATE TABLE award_investigator (AwardID BIGINT, FirstName VARCHAR(1024),LastName VARCHAR(1024), NSF_ID VARCHAR(1024), RoleCode VARCHAR(1024), FOREIGN KEY(AwardID) REFERENCES award(AwardID))")

        cursor.execute('DROP TABLE IF EXISTS award_organization;')
        cursor.execute("CREATE TABLE award_organization (AwardID BIGINT, Code BIGINT, FOREIGN KEY(AwardID) REFERENCES award(AwardID))")

        cursor.execute('DROP TABLE IF EXISTS award_performance_institution;')
        cursor.execute("CREATE TABLE award_performance_institution (AwardID BIGINT, Name VARCHAR(1024),CityName VARCHAR(1024), StateName VARCHAR(1024), FOREIGN KEY(AwardID) REFERENCES award(AwardID))")

        cursor.execute('DROP TABLE IF EXISTS award_program_reference;')
        cursor.execute("CREATE TABLE award_program_reference (AwardID BIGINT, Code VARCHAR(1024),Text VARCHAR(1024), FOREIGN KEY(AwardID) REFERENCES award(AwardID))")

        cursor.execute('DROP TABLE IF EXISTS award_program_element;')
        cursor.execute("CREATE TABLE award_program_element (AwardID BIGINT, Code VARCHAR(1024),Text VARCHAR(1024), FOREIGN KEY(AwardID) REFERENCES award(AwardID))")

        # cursor.execute('DROP TABLE IF EXISTS award_fund;')
        # cursor.execute("CREATE TABLE award_fund (AwardID BIGINT, Code BIGINT, Name VARCHAR(1024), FOREIGN KEY(AwardID) REFERENCES award(AwardID))")

#Creating the tables
#Entering the values
        print("award table is created!")
        for i, row in awardData.iterrows():
            sql = "INSERT INTO project.award VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            cursor.execute(sql, tuple(row))
            # Print("Record inserted")
            # We have to commit the connection because it is not auto-commited
            conn.commit()

        print("award_instrument table is created!")
        for i,row in award_instrumentData.iterrows():
            sql = "INSERT INTO project.award_instrument VALUES (%s,%s)"
            cursor.execute(sql, tuple(row))
            #print("Record inserted")
            # We have to commit the connection because it is not auto-commited
            conn.commit()

        print("appropriation table is created!")
        for i, row in appropriationData.iterrows():
            sql = "INSERT INTO project.appropriation VALUES (%s,%s,%s,%s)"
            cursor.execute(sql, tuple(row))
            # print("Record inserted")
            # We have to commit the connection because it is not auto-commited
            conn.commit()

        print("directorate table is created!")
        for i, row in directorateData.iterrows():
            sql = "INSERT INTO project.directorate VALUES (%s,%s,%s)"
            cursor.execute(sql, tuple(row))
            # print("Record inserted")
            # We have to commit the connection because it is not auto-commited
            conn.commit()

        print("division table is created!")
        for i, row in divisionData.iterrows():
            sql = "INSERT INTO project.division VALUES (%s,%s,%s)"
            cursor.execute(sql, tuple(row))
            # print("Record inserted")
            # We have to commit the connection because it is not auto-commited
            conn.commit()

        print("fund table is created!")
        for i, row in fundData.iterrows():
            sql = "INSERT INTO project.fund VALUES (%s,%s,%s,%s)"
            cursor.execute(sql, tuple(row))
            # print("Record inserted")
            # We have to commit the connection because it is not auto-commited
            conn.commit()

        print("institution table is created!")
        for i, row in institutionData.iterrows():
            sql = "INSERT INTO project.institution VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            cursor.execute(sql, tuple(row))
            # print("Record inserted")
            # We have to commit the connection because it is not auto-commited
            conn.commit()

        print("investigator table is created!")
        for i, row in investigatorData.iterrows():
            sql = "INSERT INTO project.investigator VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            cursor.execute(sql, tuple(row))
            # print("Record inserted")
            # We have to commit the connection because it is not auto-commited
            conn.commit()

        print("organization table is created!")
        for i, row in organizationData.iterrows():
            sql = "INSERT INTO project.organization VALUES (%s,%s)"
            cursor.execute(sql, tuple(row))
            # print("Record inserted")
            # We have to commit the connection because it is not auto-commited
            conn.commit()

        print("performance_institution table is created!")
        for i, row in performance_institutionData.iterrows():
            sql = "INSERT INTO project.performance_institution VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            cursor.execute(sql, tuple(row))
            # print("Record inserted")
            # We have to commit the connection because it is not auto-commited
            conn.commit()

        print("program_element table is created!")
        for i, row in program_elementData.iterrows():
            sql = "INSERT INTO project.program_element VALUES (%s,%s,%s)"
            cursor.execute(sql, tuple(row))
            # print("Record inserted")
            # We have to commit the connection because it is not auto-commited
            conn.commit()

        print("program_officer table is created!")
        for i, row in program_officerData.iterrows():
            sql = "INSERT INTO project.program_officer VALUES (%s,%s,%s,%s)"
            cursor.execute(sql, tuple(row))
            # print("Record inserted")
            # We have to commit the connection because it is not auto-commited
            conn.commit()

        print("program_reference table is created!")
        for i, row in program_referenceData.iterrows():
            sql = "INSERT INTO project.program_reference VALUES (%s,%s,%s)"
            cursor.execute(sql, tuple(row))
            # print("Record inserted")
            # We have to commit the connection because it is not auto-commited
            conn.commit()

        print("award_institution table is created!")
        cursor.execute('INSERT INTO project.award_institution SELECT award.AwardID, institution.Name, institution.CityName, institution.StateName, institution.ORG_UEI_NUM, institution.ORG_LGL_BUS_NAME from award INNER JOIN institution ON award.AwardID=institution.AwardID')
        # print("Record inserted")

        print("award_investigator table is created!")
        cursor.execute(
            'INSERT INTO project.award_investigator SELECT award.AwardID, investigator.FirstName, investigator.LastName, investigator.NSF_ID, investigator.RoleCode from award INNER JOIN investigator ON award.AwardID=investigator.AwardID')
        # print("Record inserted")

        print("award_organization table is created!")
        cursor.execute(
            'INSERT INTO project.award_organization SELECT award.AwardID, organization.code from award INNER JOIN organization ON award.AwardID=organization.AwardID')
        # print("Record inserted")

        print("award_performance_institution table is created!")
        cursor.execute(
            'INSERT INTO project.award_performance_institution SELECT award.AwardID, performance_institution.Name, performance_institution.CityName, performance_institution.StateName from award INNER JOIN performance_institution ON award.AwardID=performance_institution.AwardID')
        # print("Record inserted")

        print("award_program_reference table is created!")
        cursor.execute(
            'INSERT INTO project.award_program_reference SELECT award.AwardID, Program_Reference.Code, Program_Reference.Text from award INNER JOIN program_reference ON award.AwardID=program_reference.AwardID')
        # print("Record inserted")

        print("award_program_element table is created!")
        cursor.execute(
            'INSERT INTO project.award_program_element SELECT award.AwardID, program_element.Code, program_element.Text from award INNER JOIN program_element ON award.AwardID=program_element.AwardID')
        # print("Record inserted")

        #print("award_fund table is created!")
        # cursor.execute(
        #   'INSERT INTO project.award_fund SEELCT award.AwardID, fund.Code, fund.Name from award INNER JOIN fund ON award.AwardID=fund.AwardID')
        # print("Record inserted")

except Error as e:
    print("Error while connecting to MySQL", e)



