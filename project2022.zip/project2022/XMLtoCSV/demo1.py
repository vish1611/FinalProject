# Importing the required libraries
import xml.etree.ElementTree as Xet
import pandas as pd
import xmltodict
import os
import np
def make_csv(folderpath, xmlfilename, i):

    AwardCols = ["AwardTitle",
                 "AGENCY",
                 "AwardEffectiveDate",
                 "AwardExpirationDate",
                 "AwardTotalIntnAmount",
                 "AwardAmount",
                 "AbstractNarration",
                 "MinAmdLetterDate",
                 "MaxAmdLetterDate",
                 "ARRAAmount"
                 "TRAN_TYPE",
                 "CFDA_NUM",
                 "NSF_PAR_USE_FLAG",
                 "FUND_AGCY_CODE",
                 "AWDG_AGCY_CODE",
                 "AwardID",
                 "FUND_OBLG"]

    AwardInstrumentCols = ["Value",
                           "AwardID"]

    OrganizationCols = ["Code",
                        "AwardID"]

    DirectorateCols = ["Abbreviation",
                       "LongName",
                       "OrganizationCode"]

    DivisionCols = ["Abbreviation",
                    "LongName",
                    "OrganizationCode"]

    ProgramOfficerCols = ["SignBlockName",
                          "PO_EMAI",
                          "PO_PHON",
                          "AwardID"]

    ARRAAmountCols = ["TRAN_TYPE",
                      "CFDA_NUM",
                      "NSF_PAR_USE_FLAG",
                      "FUND_AGCY_CODE",
                      "AWDG_AGCY_CODE",
                      "AwardID"]

    InvestigatorCols = ["FirstName",
                        "LastName",
                        "PI_MID_INIT",
                        "PI_SUFX_NAME",
                        "PI_FULL_NAME",
                        "EmailAddress",
                        "NSF_ID",
                        "StartDate",
                        "EndDate",
                        "RoleCode",
                        "AwardID"]

    InstitutionCols = ["Name",
                       "CityName",
                       "ZipCode",
                       "PhoneNumber",
                       "StreetAddress",
                       "StreetAddress2",
                       "CountryName",
                       "StateName",
                       "StateCode",
                       "CONGRESSDISTRICT",
                       "CONGRESS_DISTRICT_ORG",
                       "ORG_UEI_NUM",
                       "ORG_LGL_BUS_NAME",
                       "ORG_PRNT_UEI_NUM",
                       "AwardID"]

    Performance_InstitutionCols = ["Name",
                                   "CityName",
                                   "StateCode",
                                   "ZipCode",
                                   "StreetAddress",
                                   "CountryCode",
                                   "CountryName",
                                   "StateName",
                                   "CountryFlag",
                                   "CONGRESSDISTRICT",
                                   "CONGRESS_DISTRICT_PERF",
                                   "AwardID"]

    ProgramElementCols = ["Code",
                          "Text",
                          "AwardID"]

    ProgramReferenceCols = ["Code",
                            "Text",
                            "AwardID"]

    AppropriationCols = ["Code",
                         "Name",
                         "APP_SYMB_ID",
                         "AwardID"]

    FundCols = ["Code",
                "Name",
                "FUND_SYMB_ID",
                "AwardID"]

    AwardRows = []
    InvestigatorRows = []
    AwardInstrumentRows = []
    OrganizationRows = []
    DirectorateRows = []
    DivisionRows = []
    ProgramOfficerRows = []
    ARRAAmountRows = []
    InstitutionRows = []
    Performance_InstitutionRows = []
    ProgramElementRows = []
    ProgramReferenceRows = []
    AppropriationRows = []
    FundRows = []

    # Parsing the XML file
    xmlparse = Xet.parse(folderpath + xmlfilename)

    with open(folderpath + xmlfilename, encoding="utf8") as xmlfile:
        xml = xmltodict.parse(xmlfile.read())

    root = xmlparse.getroot()

    #ROOT/AWARD

    for Award in root:
        node = Award.find("AwardTitle")
        if node is not None:
            award_title = node.text
        else:
            award_title = None

        node = Award.find("AGENCY")
        if node is not None:
            agency = node.text
        else:
            agency = None

        node = Award.find("AwardEffectiveDate")
        if node is not None:
            award_effective = node.text
        else:
            award_effective = None

        node = Award.find("AwardExpirationDate")
        if node is not None:
            award_expiration = node.text
        else:
            award_expiration = None

        node = Award.find("AwardTotalIntnAmount")
        if node is not None:
            award_intl_amnt = node.text
        else:
            award_intl_amnt = None

        node = Award.find("AwardAmount")
        if node is not None:
            award_amount = node.text
        else:
            award_amount = None

        node = Award.find("AbstractNarration")
        if node is not None:
            abstract = node.text
        else:
            abstract = None

        node = Award.find("MinAmdLetterDate")
        if node is not None:
            min_amd = node.text
        else:
            min_amd = None

        node = Award.find("MaxAmdLetterDate")
        if node is not None:
            max_amd = node.text
        else:
            max_amd = None

        node = Award.find("ARRAAmount")
        if node is not None:
            arra = node.text
        else:
            arra = None

        node = Award.find("TRAN_TYPE")
        if node is not None:
            tran_type = node.text
        else:
            tran_type = None

        node = Award.find("CFDA_NUM")
        if node is not None:
            cfda_num = node.text
        else:
            cfda_num = None

        node = Award.find("NSF_PAR_USE_FLAG")
        if node is not None:
            nsf_par_use_flags = node.text
        else:
            nsf_par_use_flags = None

        node = Award.find("FUND_AGCY_CODE")
        if node is not None:
            fund_agcy_code = node.text
        else:
            fund_agcy_code = None

        node = Award.find("AWDG_AGCY_CODE")
        if node is not None:
            awdg_agcy_code = node.text
        else:
            awdg_agcy_code = None

        node = Award.find("AwardID")
        if node is not None:
            award_id = node.text
        else:
            award_id = None

        node = Award.find("FUND_OBLG")
        if node is not None:
            fund_oblg = node.text
        else:
            fund_oblg = None

        AwardRows.append({"AwardTitle": award_title,
                          "AGENCY": agency,
                          "AwardEffectiveDate": award_effective,
                          "AwardExpirationDate": award_expiration,
                          "AwardTotalIntnAmount": award_intl_amnt,
                          "AwardAmount": award_amount,
                          "AbstractNarration": abstract,
                          "MinAmdLetterDate": min_amd,
                          "MaxAmdLetterDate": max_amd,
                          "ARRAAmount": arra,
                          "TRAN_TYPE": tran_type,
                          "CFDA_NUM": cfda_num,
                          "NSF_PAR_USE_FLAG": nsf_par_use_flags,
                          "FUND_AGCY_CODE": fund_agcy_code,
                          "AWDG_AGCY_CODE": awdg_agcy_code,
                          "AwardID": award_id,
                          "FUND_OBLG": fund_oblg})

    award_df = pd.DataFrame(AwardRows, columns=AwardCols)
    award_df = award_df.replace(np.nan, 0)

    if i==1:
        award_df.to_csv('./CSVfiles/award.csv', mode='a',index=False)
    else:
    # Writing dataframe to csv
        award_df.to_csv('./CSVfiles/award.csv', mode='a', header=False, index=False)


    #ROOT/AWARD/AWARD_INSTRUMENT

    for Award in root:

        AwardInstrumentNode = Award.findall("AwardInstrument")
        for AwardInstrument in AwardInstrumentNode:

            node = AwardInstrument.find("Value")
            if node is not None:
                value = node.text
            else:
                value = None

            node = Award.find("AwardID")
            if node is not None:
                award_id = node.text
            else:
                award_id = None

            AwardInstrumentRows.append({"Value": value,
                                        "AwardID": award_id})

    award_instrument_df = pd.DataFrame(AwardInstrumentRows, columns=AwardInstrumentCols)

    # Writing dataframe to csv
    if i == 1:
        award_instrument_df.to_csv('./CSVfiles/award_instrument.csv', mode='a', index=False)
    else:
        # Writing dataframe to csv
        award_instrument_df.to_csv('./CSVfiles/award_instrument.csv', mode='a', header=False, index=False)

    #ROOT/AWARD/ORGANIZATION

    for Award in root:

        OrganizationNode = Award.findall("Organization")
        for Organization in OrganizationNode:

            node = Organization.find("Code")
            if node is not None:
                code = node.text
            else:
                code = None

            node = Award.find("AwardID")
            if node is not None:
                award_id = node.text
            else:
                award_id = None

            OrganizationRows.append({"Code": code,
                                     "AwardID": award_id})

    organization_df = pd.DataFrame(OrganizationRows, columns=OrganizationCols)
    organization_df = organization_df.replace(np.nan, 0)

    if i == 1:
        organization_df.to_csv('./CSVfiles/organization.csv', mode='a', index=False)
    else:
        # Writing dataframe to csv
        organization_df.to_csv('./CSVfiles/organization.csv', mode='a', header=False, index=False)


    #ROOT/AWARD/ORGANIZATION/DIRECTORATE

    for Award in root:

        OrganizationNode = Award.findall("Organization")
        for Organization in OrganizationNode:

            DirectorateNode = Organization.findall("Directorate")
            for Directorate in DirectorateNode:

                node = Directorate.find("Abbreviation")
                if node is not None:
                    abb = node.text
                else:
                    abb = None

                node = Directorate.find("LongName")
                if node is not None:
                    long_name = node.text
                else:
                    long_name = None

                node = Organization.find("Code")
                if node is not None:
                    org_code = node.text
                else:
                    org_code = None

                DirectorateRows.append({"Abbreviation": abb,
                                        "LongName": long_name,
                                        "OrganizationCode": code})

    directorate_df = pd.DataFrame(DirectorateRows, columns=DirectorateCols)
    directorate_df = directorate_df.replace(np.nan, 0)

    if i == 1:
        directorate_df.to_csv('./CSVfiles/directorate.csv', mode='a', index=False)
    else:
        # Writing dataframe to csv
        directorate_df.to_csv('./CSVfiles/directorate.csv', mode='a', header=False, index=False)


    #ROOT/AWARD/ORGANIZATION/DIVISION

    for Award in root:

        OrganizationNode = Award.findall("Organization")
        for Organization in OrganizationNode:

            DivisionNode = Organization.findall("Division")
            for Division in DivisionNode:

                node = Division.find("Abbreviation")
                if node is not None:
                    abb = node.text
                else:
                    abb = None

                node = Division.find("LongName")
                if node is not None:
                    long_name = node.text
                else:
                    long_name = None

                node = Division.find("Code")
                if node is not None:
                    org_code = node.text
                else:
                    org_code = None

                DivisionRows.append({"Abbreviation": abb,
                                     "LongName": long_name,
                                     "OrganizationCode": code})


    division_df = pd.DataFrame(DivisionRows, columns=DivisionCols)
    division_df = division_df.replace(np.nan, 0)

    if i == 1:
        division_df.to_csv('./CSVfiles/division.csv', mode='a', index=False)
    else:
        # Writing dataframe to csv
        division_df.to_csv('./CSVfiles/division.csv', mode='a', header=False, index=False)

    #ROOT/AWARD/PROGRAM_OFFICER

    for Award in root:

        ProgramOfficerNode = Award.findall("ProgramOfficer")
        for ProgramOfficer in ProgramOfficerNode:

            node = ProgramOfficer.find("SignBlockName")
            if node is not None:
                sign_block_name = node.text
            else:
                sign_block_name = None

            node = ProgramOfficer.find("PO_EMAI")
            if node is not None:
                po_email = node.text
            else:
                po_email = None

            node = ProgramOfficer.find("PO_PHON")
            if node is not None:
                po_phone = node.text
            else:
                po_phone = None

            node = Award.find("AwardID")
            if node is not None:
                award_id = node.text
            else:
                award_id = None

            ProgramOfficerRows.append({"SignBlockName": sign_block_name,
                                       "PO_EMAI": po_email,
                                       "PO_PHON": po_phone,
                                       "AwardID": award_id})

    program_officer_df = pd.DataFrame(ProgramOfficerRows, columns=ProgramOfficerCols)
    program_officer_df = program_officer_df.replace(np.nan, 0)

    if i == 1:
        program_officer_df.to_csv('./CSVfiles/program_officer.csv', mode='a', index=False)
    else:
        # Writing dataframe to csv
        program_officer_df.to_csv('./CSVfiles/program_officer.csv', mode='a', header=False, index=False)

    #ROOT/AWARD/INVESTIGATOR
    for Award in root:

        InvestigatorNode = Award.findall("Investigator")
        # print(InvestigatorNode)
        for Investigator in InvestigatorNode:
            # print(Investigator)

            node = Investigator.find("FirstName")
            if node is not None:
                fname = node.text
            else:
                fname = None

            node = Investigator.find("LastName")
            if node is not None:
                lname = node.text
            else:
                lname = None

            node = Investigator.find("PI_MID_INIT")
            if node is not None:
                pi_mid_init = node.text
            else:
                pi_mid_init = None

            node = Investigator.find("PI_SUFX_NAME")
            if node is not None:
                pi_sufx = node.text
            else:
                pi_sufx = None

            node = Investigator.find("PI_FULL_NAME")
            if node is not None:
                pi_full_name = node.text
            else:
                pi_full_name = None

            node = Investigator.find("EmailAddress")
            if node is not None:
                email = node.text
            else:
                email = None

            node = Investigator.find("NSF_ID")
            if node is not None:
                nsf_id = node.text
            else:
                nsf_id = None

            node = Investigator.find("StartDate")
            if node is not None:
                start_date = node.text
            else:
                start_date = None

            node = Investigator.find("EndDate")
            if node is not None:
                end_date = node.text
            else:
                end_date = None

            node = Investigator.find("RoleCode")
            if node is not None:
                role_code = node.text
            else:
                role_code = None

            InvestigatorRows.append({"FirstName": fname,
                                     "LastName": lname,
                                     "PI_MID_INIT": pi_mid_init,
                                     "PI_SUFX_NAME": pi_sufx,
                                     "PI_FULL_NAME": pi_full_name,
                                     "EmailAddress": email,
                                     "NSF_ID": nsf_id,
                                     "StartDate": start_date,
                                     "EndDate": end_date,
                                     "RoleCode": role_code})

    investigator_df = pd.DataFrame(InvestigatorRows, columns=InvestigatorCols)
    investigator_df = investigator_df.replace(np.nan, 0)

    if i == 1:
        investigator_df.to_csv('./CSVfiles/investigator.csv', mode='a', index=False)
    else:
        # Writing dataframe to csv
        investigator_df.to_csv('./CSVfiles/investigator.csv', mode='a', header=False, index=False)

    #ROOT/AWARD/INSTITUTION

    for Award in root:

        InstitutionNode = Award.findall("Institution")
        for Institution in InstitutionNode:

            node = Institution.find("Name")
            if node is not None:
                name = node.text
            else:
                name = None

            node = Institution.find("CityName")
            if node is not None:
                city = node.text
            else:
                city = None

            node = Institution.find("ZipCode")
            if node is not None:
                zip_code = node.text
            else:
                zip_code = None

            node = Institution.find("PhoneNumber")
            if node is not None:
                phone_num = node.text
            else:
                phone_num = None

            node = Institution.find("StreetAddress")
            if node is not None:
                add = node.text
            else:
                add = None

            node = Institution.find("StreetAddress2")
            if node is not None:
                add2 = node.text
            else:
                add2 = None

            node = Institution.find("CountryName")
            if node is not None:
                country_name = node.text
            else:
                country_name = None

            node = Institution.find("StateName")
            if node is not None:
                state_name = node.text
            else:
                state_name = None

            node = Institution.find("StateCode")
            if node is not None:
                state_code = node.text
            else:
                state_code = None

            node = Institution.find("CONGRESSDISTRICT")
            if node is not None:
                congressdist = node.text
            else:
                congressdist = None

            node = Institution.find("CONGRESS_DISTRICT_ORG")
            if node is not None:
                congress_dist_org = node.text
            else:
                congress_dist_org = None

            node = Institution.find("ORG_UEI_NUM")
            if node is not None:
                org_uei = node.text
            else:
                org_uei = None

            node = Institution.find("ORG_LGL_BUS_NAME")
            if node is not None:
                org_lgl = node.text
            else:
                org_lgl = None

            node = Institution.find("ORG_PRNT_UEI_NUM")
            if node is not None:
                org_prnt = node.text
            else:
                org_prnt = None

            node = Award.find("AwardID")
            if node is not None:
                award_id = node.text
            else:
                award_id = None

            InstitutionRows.append({"Name": name,
                                    "CityName": city,
                                    "ZipCode": zip_code,
                                    "PhoneNumber": phone_num,
                                    "StreetAddress": add,
                                    "StreetAddress2": add2,
                                    "CountryName": country_name,
                                    "StateName": state_name,
                                    "StateCode": state_code,
                                    "CONGRESSDISTRICT": congressdist,
                                    "CONGRESS_DISTRICT_ORG": congress_dist_org,
                                    "ORG_UEI_NUM": org_uei,
                                    "ORG_LGL_BUS_NAME": org_lgl,
                                    "ORG_PRNT_UEI_NUM": org_prnt,
                                    "AwardID": award_id})

    institution_df = pd.DataFrame(InstitutionRows, columns=InstitutionCols)
    institution_df = institution_df.replace(np.nan, 0)

    if i == 1:
        institution_df.to_csv('./CSVfiles/institution.csv', mode='a', index=False)
    else:
        # Writing dataframe to csv
        institution_df.to_csv('./CSVfiles/institution.csv', mode='a', header=False, index=False)


    #ROOT/AWARD/PERFORMANCE_INSTITUTION

    for Award in root:

        PerformanceInstitutionNode = Award.findall("Performance_Institution")
        for PerformanceInstitution in PerformanceInstitutionNode:
            node = PerformanceInstitution.find("Name")
            if node is not None:
                name = node.text
            else:
                name = None

            node = PerformanceInstitution.find("CityName")
            if node is not None:
                city_name = node.text
            else:
                city_name = None

            node = PerformanceInstitution.find("StateCode")
            if node is not None:
                state_code = node.text
            else:
                state_code = None

            node = PerformanceInstitution.find("ZipCode")
            if node is not None:
                zip_code = node.text
            else:
                zip_code = None

            node = PerformanceInstitution.find("StreetAddress")
            if node is not None:
                stress_address = node.text
            else:
                stress_address = None

            node = PerformanceInstitution.find("CountryCode")
            if node is not None:
                country_code = node.text
            else:
                country_code = None

            node = PerformanceInstitution.find("CountryName")
            if node is not None:
                country_name = node.text
            else:
                country_name = None
            node = PerformanceInstitution.find("StateName")
            if node is not None:
                state_name = node.text
            else:
                state_name = None

            node = PerformanceInstitution.find("CountryFlag")
            if node is not None:
                country_flag = node.text
            else:
                country_flag = None

            node = PerformanceInstitution.find("CONGRESSDISTRICT")
            if node is not None:
                congress_district = node.text
            else:
                congress_district = None

            node = PerformanceInstitution.find("CONGRESS_DISTRICT_PERF")
            if node is not None:
                congress_district_perf = node.text
            else:
                congress_district_perf = None

            node = Award.find("AwardID")
            if node is not None:
                award_id = node.text
            else:
                award_id = None

            Performance_InstitutionRows.append({"Name": name,
                                                "CityName": city_name,
                                                "StateCode": state_code,
                                                "ZipCode": zip_code,
                                                "StreetAddress": stress_address,
                                                "CountryCode": country_code,
                                                "CountryName": country_name,
                                                "StateName": state_name,
                                                "CountryFlag": country_flag,
                                                "CONGRESSDISTRICT": congress_district,
                                                "CONGRESS_DISTRICT_PERF": congress_district_perf,
                                                "AwardID": award_id})

    performance_institution_df = pd.DataFrame(Performance_InstitutionRows, columns=Performance_InstitutionCols)
    performance_institution_df = performance_institution_df.replace(np.nan, 0)

    if i == 1:
        performance_institution_df.to_csv('./CSVfiles/performance_institution.csv', mode='a', index=False)
    else:
        # Writing dataframe to csv
        performance_institution_df.to_csv('./CSVfiles/performance_institution.csv', mode='a', index=False, header=False)


    #ROOT/AWARD/PROGRAM_ELEMENT

    for Award in root:

        ProgramElementNode = Award.findall("ProgramElement")
        for ProgramElement in ProgramElementNode:

            node = ProgramElement.find("Code")
            if node is not None:
                code = node.text
            else:
                code = None

            node = ProgramElement.find("Text")
            if node is not None:
                text = node.text
            else:
                text = None

            node = Award.find("AwardID")
            if node is not None:
                award_id = node.text
            else:
                award_id = None

            ProgramElementRows.append({"Code": code,
                                       "Text": text,
                                       "AwardID": award_id})

    program_element_df = pd.DataFrame(ProgramElementRows, columns=ProgramElementCols)
    program_element_df = program_element_df.replace(np.nan, 0)

    if i == 1:
        program_element_df.to_csv('./CSVfiles/program_element.csv', mode='a', index=False)
    else:
        # Writing dataframe to csv
        program_element_df.to_csv('./CSVfiles/program_element.csv', mode='a', index=False, header=False)


    #ROOT/AWARD/PROGRAM_REFERENCE

    for Award in root:

        ProgramReferenceNode = Award.findall("ProgramReference")
        for ProgramReference in ProgramReferenceNode:

            node = ProgramReference.find("Code")
            if node is not None:
                code = node.text
            else:
                code = None

            node = ProgramReference.find("Text")
            if node is not None:
                text = node.text
            else:
                text = None

            node = Award.find("AwardID")
            if node is not None:
                award_id = node.text
            else:
                award_id = None

            ProgramReferenceRows.append({"Code": code,
                                         "Text": text,
                                         "AwardID": award_id})

    program_reference_df = pd.DataFrame(ProgramReferenceRows, columns=ProgramReferenceCols)
    program_reference_df = program_reference_df.replace(np.nan, 0)

    if i == 1:
        program_reference_df.to_csv('./CSVfiles/program_reference.csv', mode='a', index=False)
    else:
        # Writing dataframe to csv
        program_reference_df.to_csv('./CSVfiles/program_reference.csv', mode='a', index=False, header=False)


    #ROOT/AWARD/APPROPRIATION

    for Award in root:

        AppropriationNode = Award.findall("Appropriation")
        for Appropriation in AppropriationNode:

            node = Appropriation.find("Code")
            if node is not None:
                code = node.text
            else:
                code = None

            node = Appropriation.find("Name")
            if node is not None:
                name = node.text
            else:
                name = None

            node = Appropriation.find("APP_SYMB_ID")
            if node is not None:
                app_symb = node.text
            else:
                app_symb = None

            node = Award.find("AwardID")
            if node is not None:
                award_id = node.text
            else:
                award_id = None

            AppropriationRows.append({"Code": code,
                                      "Name": name,
                                      "APP_SYMB_ID": app_symb,
                                      "AwardID": award_id})

    appropriation_df = pd.DataFrame(AppropriationRows, columns=AppropriationCols)
    appropriation_df = appropriation_df.replace(np.nan, 0)

    if i == 1:
        appropriation_df.to_csv('./CSVfiles/appropriation.csv', mode='a', index=False)
    else:
        # Writing dataframe to csv
        appropriation_df.to_csv('./CSVfiles/appropriation.csv', mode='a', index=False, header=False)



    #ROOT/AWARD/FUND

    for Award in root:

        FundNode = Award.findall("Fund")
        for Fund in FundNode:

            node = Fund.find("Code")
            if node is not None:
                code = node.text
            else:
                code = None

            node = Fund.find("Name")
            if node is not None:
                name = node.text
            else:
                name = None

            node = Fund.find("APP_SYMB_ID")
            if node is not None:
                app_symb = node.text
            else:
                app_symb = None

            node = Award.find("AwardID")
            if node is not None:
                award_id = node.text
            else:
                award_id = None

            FundRows.append({"Code": code,
                             "Name": name,
                             "APP_SYMB_ID": app_symb,
                             "AwardID": award_id})

    fund_df = pd.DataFrame(FundRows, columns=FundCols)
    fund_df = fund_df.replace(np.nan, 0)

    if i == 1:
        fund_df.to_csv('./CSVfiles/fund.csv', mode='a', index=False)
    else:
        # Writing dataframe to csv
        fund_df.to_csv('./CSVfiles/fund.csv', mode='a', index=False, header=False)

    xmlfile.close()


path = 'D:\\final_project\\2021\\'
i=0
for filename in os.listdir(path):
    if filename.endswith('.xml'):
        i=i+1
        print(path + filename)
        make_csv(path, filename, i)